// Real Email Service Integration
class EmailService {
    constructor() {
        this.provider = 'sendgrid'; // or 'mailgun', 'ses'
        this.apiKey = this.loadApiKey();
        this.config = this.loadConfig();
    }

    // SendGrid Integration
    async sendWithSendGrid(emailData) {
        const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                personalizations: [{
                    to: [{ email: emailData.to }],
                    dynamic_template_data: emailData.templateData
                }],
                from: {
                    email: this.config.fromEmail,
                    name: this.config.fromName
                },
                template_id: emailData.templateId,
                tracking_settings: {
                    click_tracking: { enable: true },
                    open_tracking: { enable: true }
                }
            })
        });

        if (!response.ok) {
            throw new Error(`SendGrid API error: ${response.statusText}`);
        }

        return await response.json();
    }

    // Mailgun Integration
    async sendWithMailgun(emailData) {
        const formData = new FormData();
        formData.append('from', `${this.config.fromName} <${this.config.fromEmail}>`);
        formData.append('to', emailData.to);
        formData.append('subject', emailData.subject);
        formData.append('html', emailData.html);
        formData.append('o:tracking', 'yes');
        formData.append('o:tracking-clicks', 'yes');
        formData.append('o:tracking-opens', 'yes');

        const response = await fetch(`https://api.mailgun.net/v3/${this.config.domain}/messages`, {
            method: 'POST',
            headers: {
                'Authorization': 'Basic ' + btoa(`api:${this.apiKey}`)
            },
            body: formData
        });

        if (!response.ok) {
            throw new Error(`Mailgun API error: ${response.statusText}`);
        }

        return await response.json();
    }

    // Amazon SES Integration
    async sendWithSES(emailData) {
        // SES implementation would go here
        // This requires AWS SDK and server-side implementation
        console.log('SES integration requires server-side setup');
    }

    // Main send method
    async sendEmail(emailData) {
        try {
            let result;
            
            switch (this.provider) {
                case 'sendgrid':
                    result = await this.sendWithSendGrid(emailData);
                    break;
                case 'mailgun':
                    result = await this.sendWithMailgun(emailData);
                    break;
                case 'ses':
                    result = await this.sendWithSES(emailData);
                    break;
                default:
                    throw new Error('Unknown email provider');
            }

            // Log successful send
            this.logEmailSent(emailData, result);
            return result;

        } catch (error) {
            // Log failed send
            this.logEmailFailed(emailData, error);
            throw error;
        }
    }

    logEmailSent(emailData, result) {
        const logEntry = {
            id: Date.now().toString(),
            to: emailData.to,
            subject: emailData.subject,
            type: emailData.type,
            provider: this.provider,
            messageId: result.id || result.messageId,
            sentAt: new Date().toISOString(),
            status: 'sent'
        };

        const history = Utils.loadFromStorage('emailHistory') || [];
        history.unshift(logEntry);
        Utils.saveToStorage('emailHistory', history);
    }

    logEmailFailed(emailData, error) {
        const logEntry = {
            id: Date.now().toString(),
            to: emailData.to,
            subject: emailData.subject,
            type: emailData.type,
            provider: this.provider,
            error: error.message,
            failedAt: new Date().toISOString(),
            status: 'failed'
        };

        const history = Utils.loadFromStorage('emailHistory') || [];
        history.unshift(logEntry);
        Utils.saveToStorage('emailHistory', history);
    }

    loadApiKey() {
        return Utils.loadFromStorage('emailApiKey') || '';
    }

    loadConfig() {
        return Utils.loadFromStorage('emailConfig') || {
            fromEmail: 'noreply@mystyl.com',
            fromName: 'MYSTYL',
            domain: 'mg.mystyl.com',
            provider: 'sendgrid'
        };
    }

    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        Utils.saveToStorage('emailConfig', this.config);
    }

    setApiKey(apiKey) {
        this.apiKey = apiKey;
        Utils.saveToStorage('emailApiKey', apiKey);
    }

    setProvider(provider) {
        this.provider = provider;
        Utils.saveToStorage('emailProvider', provider);
    }

    // Test connection
    async testConnection() {
        try {
            const testEmail = {
                to: this.config.testEmail || 'test@example.com',
                subject: 'Test Connection - MYSTYL Email System',
                html: '<p>This is a test email from MYSTYL email system.</p>',
                type: 'test'
            };

            await this.sendEmail(testEmail);
            return { success: true, message: 'Connection test successful' };
        } catch (error) {
            return { success: false, message: error.message };
        }
    }

    // Get delivery statistics
    getDeliveryStats() {
        const history = Utils.loadFromStorage('emailHistory') || [];
        const sent = history.filter(email => email.status === 'sent').length;
        const failed = history.filter(email => email.status === 'failed').length;
        const total = history.length;

        return {
            sent,
            failed,
            total,
            successRate: total > 0 ? ((sent / total) * 100).toFixed(1) : 0
        };
    }
}

// Initialize email service
window.emailService = new EmailService();
