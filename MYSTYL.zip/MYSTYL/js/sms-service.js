class SMSService {
    constructor() {
        this.provider = 'twilio'; // or 'plivo', 'nexmo'
        this.apiKey = this.loadApiKey();
        this.config = this.loadConfig();
        this.enabled = this.config.enabled || false;
    }

    // Twilio Integration
    async sendWithTwilio(smsData) {
        const response = await fetch('https://api.twilio.com/2010-04-01/Accounts/ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/Messages.json', {
            method: 'POST',
            headers: {
                'Authorization': 'Basic ' + btoa(`${this.config.accountSid}:${this.apiKey}`),
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                To: smsData.to,
                From: this.config.fromNumber,
                Body: smsData.body
            })
        });

        if (!response.ok) {
            throw new Error(`Twilio API error: ${response.statusText}`);
        }

        return await response.json();
    }

    // Main SMS sending method
    async sendSMS(smsData) {
        if (!this.enabled) {
            console.log('SMS notifications are disabled');
            return;
        }

        try {
            let result;
            
            switch (this.provider) {
                case 'twilio':
                    result = await this.sendWithTwilio(smsData);
                    break;
                // Add other providers here
                default:
                    throw new Error('Unknown SMS provider');
            }

            this.logSMSSent(smsData, result);
            return result;

        } catch (error) {
            this.logSMSFailed(smsData, error);
            throw error;
        }
    }

    // SMS Templates
    getSMSTemplates() {
        return {
            orderConfirmed: {
                id: 'order-confirmed',
                name: 'Order Confirmation',
                template: 'Hi {{customer_name}}, your order {{order_number}} has been confirmed. Total: £{{order_total}}',
                triggers: ['order_placed'],
                enabled: true
            },
            orderShipped: {
                id: 'order-shipped',
                name: 'Order Shipped',
                template: 'Your order {{order_number}} has shipped! Track: {{tracking_url}}',
                triggers: ['order_shipped'],
                enabled: true
            },
            orderDelivered: {
                id: 'order-delivered',
                name: 'Order Delivered',
                template: 'Your order {{order_number}} has been delivered. We hope you love it!',
                triggers: ['order_delivered'],
                enabled: true
            },
            brokerCommission: {
                id: 'broker-commission',
                name: 'Broker Commission',
                template: 'You earned £{{commission_amount}} commission from {{customer_name}}\'s order!',
                triggers: ['commission_earned'],
                enabled: true
            }
        };
    }

    // Send SMS based on template
    async sendTemplateSMS(templateId, data) {
        const templates = this.getSMSTemplates();
        const template = templates[templateId];
        
        if (!template || !template.enabled) {
            return;
        }

        const body = this.replacePlaceholders(template.template, data);
        
        await this.sendSMS({
            to: data.phoneNumber,
            body: body,
            type: templateId
        });
    }

    replacePlaceholders(template, data) {
        let result = template;
        for (const [key, value] of Object.entries(data)) {
            const placeholder = new RegExp(`{{${key}}}`, 'g');
            result = result.replace(placeholder, value);
        }
        return result;
    }

    // Event handlers for integration with email system
    setupEventListeners() {
        window.addEventListener('orderPlaced', (e) => {
            if (e.detail.phoneNumber) {
                this.sendTemplateSMS('orderConfirmed', e.detail);
            }
        });

        window.addEventListener('orderShipped', (e) => {
            if (e.detail.phoneNumber) {
                this.sendTemplateSMS('orderShipped', e.detail);
            }
        });

        window.addEventListener('commissionEarned', (e) => {
            if (e.detail.brokerPhone) {
                this.sendTemplateSMS('brokerCommission', e.detail);
            }
        });
    }

    // Logging
    logSMSSent(smsData, result) {
        const logEntry = {
            id: Date.now().toString(),
            to: smsData.to,
            body: smsData.body,
            type: smsData.type,
            provider: this.provider,
            messageId: result.sid || result.messageId,
            sentAt: new Date().toISOString(),
            status: 'sent'
        };

        const history = Utils.loadFromStorage('smsHistory') || [];
        history.unshift(logEntry);
        Utils.saveToStorage('smsHistory', history);
    }

    logSMSFailed(smsData, error) {
        const logEntry = {
            id: Date.now().toString(),
            to: smsData.to,
            body: smsData.body,
            type: smsData.type,
            provider: this.provider,
            error: error.message,
            failedAt: new Date().toISOString(),
            status: 'failed'
        };

        const history = Utils.loadFromStorage('smsHistory') || [];
        history.unshift(logEntry);
        Utils.saveToStorage('smsHistory', history);
    }

    // Configuration
    loadApiKey() {
        return Utils.loadFromStorage('smsApiKey') || '';
    }

    loadConfig() {
        return Utils.loadFromStorage('smsConfig') || {
            enabled: false,
            fromNumber: '+1234567890',
            accountSid: '',
            testMode: true,
            testNumber: '+1234567890'
        };
    }

    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        this.enabled = this.config.enabled;
        Utils.saveToStorage('smsConfig', this.config);
    }

    setApiKey(apiKey) {
        this.apiKey = apiKey;
        Utils.saveToStorage('smsApiKey', apiKey);
    }

    // Test method
    async testSMS() {
        try {
            const testData = {
                to: this.config.testNumber,
                body: 'Test SMS from MYSTYL notification system',
                type: 'test'
            };

            await this.sendSMS(testData);
            return { success: true, message: 'SMS test successful' };
        } catch (error) {
            return { success: false, message: error.message };
        }
    }

    // Get statistics
    getSMSStats() {
        const history = Utils.loadFromStorage('smsHistory') || [];
        const sent = history.filter(sms => sms.status === 'sent').length;
        const failed = history.filter(sms => sms.status === 'failed').length;
        const total = history.length;

        return {
            sent,
            failed,
            total,
            successRate: total > 0 ? ((sent / total) * 100).toFixed(1) : 0
        };
    }
}

// Initialize SMS service
window.smsService = new SMSService();

// Integrate with email system
document.addEventListener('DOMContentLoaded', () => {
    window.smsService.setupEventListeners();
});[file content end]