// Enhanced Category Management System
class CategoryManager {
    constructor() {
        this.categories = this.loadCategories();
        this.currentCategory = '';
        this.currentSubcategory = '';
        this.init();
    }

    init() {
        this.setupCategoryListeners();
        this.applyCategoryFilters();
    }

    loadCategories() {
        return {
            men: {
                name: "Men's Collection",
                description: "Premium sportswear and accessories for men",
                icon: "fas fa-male",
                subcategories: {
                    shoes: {
                        name: "Men's Shoes",
                        description: "Performance and lifestyle footwear",
                        types: ["Running", "Training", "Lifestyle", "Basketball", "Football"]
                    },
                    clothing: {
                        name: "Men's Clothing",
                        description: "Activewear and casual apparel",
                        types: ["T-Shirts", "Hoodies", "Shorts", "Jackets", "Pants"]
                    },
                    accessories: {
                        name: "Men's Accessories",
                        description: "Essential sports accessories",
                        types: ["Bags", "Hats", "Socks", "Watches", "Sunglasses"]
                    }
                }
            },
            women: {
                name: "Women's Collection",
                description: "Stylish activewear and gear for women",
                icon: "fas fa-female",
                subcategories: {
                    shoes: {
                        name: "Women's Shoes",
                        description: "Performance and fashion footwear",
                        types: ["Running", "Training", "Yoga", "Lifestyle", "Tennis"]
                    },
                    clothing: {
                        name: "Women's Clothing",
                        description: "Activewear and fitness apparel",
                        types: ["Leggings", "Sports Bras", "Tops", "Shorts", "Jackets"]
                    },
                    accessories: {
                        name: "Women's Accessories",
                        description: "Fitness and lifestyle accessories",
                        types: ["Bags", "Headbands", "Yoga Mats", "Water Bottles", "Jewelry"]
                    }
                }
            },
            kids: {
                name: "Kids Collection",
                description: "Fun and durable sportswear for children",
                icon: "fas fa-child",
                subcategories: {
                    shoes: {
                        name: "Kids Shoes",
                        description: "Comfortable and supportive footwear",
                        types: ["Running", "School", "Football", "Basketball", "Casual"]
                    },
                    clothing: {
                        name: "Kids Clothing",
                        description: "Play-friendly activewear",
                        types: ["T-Shirts", "Shorts", "Tracksuits", "Jackets", "Dresses"]
                    },
                    accessories: {
                        name: "Kids Accessories",
                        description: "Fun sports accessories",
                        types: ["Backpacks", "Hats", "Water Bottles", "Toys", "Socks"]
                    }
                }
            },
            sport: {
                name: "Sport Collection",
                description: "Professional sports equipment and gear",
                icon: "fas fa-football-ball",
                subcategories: {
                    equipment: {
                        name: "Sports Equipment",
                        description: "Professional training equipment",
                        types: ["Balls", "Rackets", "Weights", "Mats", "Training Gear"]
                    },
                    footwear: {
                        name: "Sports Footwear",
                        description: "Specialized sports shoes",
                        types: ["Cleats", "Court Shoes", "Running Spikes", "Training Shoes"]
                    },
                    apparel: {
                        name: "Sports Apparel",
                        description: "Performance sportswear",
                        types: ["Jerseys", "Shorts", "Compression Wear", "Team Uniforms"]
                    }
                }
            }
        };
    }

    setupCategoryListeners() {
        // This will be called from category pages
        const urlParams = new URLSearchParams(window.location.search);
        this.currentCategory = urlParams.get('category') || '';
        this.currentSubcategory = urlParams.get('subcategory') || '';

        this.updateCategoryDisplay();
    }

    updateCategoryDisplay() {
        if (this.currentCategory && this.categories[this.currentCategory]) {
            const category = this.categories[this.currentCategory];
            
            // Update page title
            document.title = `${category.name} - ${window.zawadiApp?.brandConfig?.name || 'MYSTYL'}`;
            
            // Update breadcrumb
            this.updateBreadcrumb();
            
            // Load subcategories
            this.loadSubcategories();
            
            // Load products for this category
            this.loadCategoryProducts();
        }
    }

    updateBreadcrumb() {
        const breadcrumb = document.getElementById('categoryBreadcrumb');
        if (!breadcrumb) return;

        const category = this.categories[this.currentCategory];
        let breadcrumbHTML = `
            <a href="index.html">Home</a>
            <span class="breadcrumb-separator">/</span>
            <a href="categories.html?category=${this.currentCategory}">${category.name}</a>
        `;

        if (this.currentSubcategory && category.subcategories[this.currentSubcategory]) {
            const subcategory = category.subcategories[this.currentSubcategory];
            breadcrumbHTML += `
                <span class="breadcrumb-separator">/</span>
                <span class="current">${subcategory.name}</span>
            `;
        }

        breadcrumb.innerHTML = breadcrumbHTML;
    }

    loadSubcategories() {
        const container = document.getElementById('subcategoriesGrid');
        if (!container) return;

        const category = this.categories[this.currentCategory];
        if (!category) return;

        container.innerHTML = Object.entries(category.subcategories).map(([key, subcat]) => `
            <div class="subcategory-card" onclick="window.location.href='category-products.html?category=${this.currentCategory}&subcategory=${key}'">
                <div class="subcategory-icon">
                    <i class="${category.icon}"></i>
                </div>
                <div class="subcategory-content">
                    <h3>${subcat.name}</h3>
                    <p>${subcat.description}</p>
                    <div class="subcategory-types">
                        ${subcat.types.map(type => `<span class="type-tag">${type}</span>`).join('')}
                    </div>
                    <div class="subcategory-arrow">
                        <i class="fas fa-arrow-right"></i>
                    </div>
                </div>
            </div>
        `).join('');
    }

    loadCategoryProducts() {
        const container = document.getElementById('categoryProducts');
        if (!container) return;

        // Get products for current category/subcategory
        const products = productManager.getProductsByCategory(this.currentCategory, this.currentSubcategory);
        
        if (products.length === 0) {
            container.innerHTML = `
                <div class="no-products">
                    <i class="fas fa-box-open"></i>
                    <h3>No Products Found</h3>
                    <p>We're restocking this category. Check back soon!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = products.map(product => `
            <div class="product-card" onclick="window.location.href='product.html?id=${product.id}&category=${this.currentCategory}&subcategory=${this.currentSubcategory}'">
                ${product.isBestseller ? '<div class="product-badge">Bestseller</div>' : ''}
                ${!product.inStock ? '<div class="product-badge out-of-stock">Out of Stock</div>' : ''}
                <div class="product-image">
                    <i class="fas fa-tshirt"></i>
                    <div class="product-actions">
                        <button class="btn-icon wishlist-btn" onclick="event.stopPropagation(); addToWishlist(${product.id})">
                            <i class="far fa-heart"></i>
                        </button>
                        <button class="btn-icon quick-view-btn" onclick="event.stopPropagation(); quickView(${product.id})">
                            <i class="far fa-eye"></i>
                        </button>
                    </div>
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <div class="product-meta">
                        <div class="price">£${product.price}</div>
                        <div class="rating">
                            <i class="fas fa-star"></i>
                            <span>${product.rating}</span>
                        </div>
                    </div>
                    <p class="product-description">${product.description.substring(0, 80)}...</p>
                    <button class="btn add-to-cart" onclick="event.stopPropagation(); productManager.addToCart(${product.id})" ${!product.inStock ? 'disabled' : ''}>
                        ${product.inStock ? 'Add to Cart' : 'Out of Stock'}
                    </button>
                </div>
            </div>
        `).join('');
    }

    applyCategoryFilters() {
        // Apply filters based on current category and subcategory
        if (this.currentCategory) {
            productManager.currentFilters.category = this.currentCategory;
        }
        if (this.currentSubcategory) {
            productManager.currentFilters.subcategory = this.currentSubcategory;
        }
        
        productManager.applyFilters();
    }

    getCategoryProducts(category, subcategory = '') {
        return productManager.products.filter(product => {
            let matches = product.category === category;
            if (subcategory && product.subcategory) {
                matches = matches && product.subcategory.toLowerCase() === subcategory.toLowerCase();
            }
            return matches;
        });
    }

    getFeaturedProductsByCategory(category, limit = 4) {
        return this.getCategoryProducts(category)
            .filter(product => product.featured)
            .slice(0, limit);
    }

    getRelatedProducts(currentProduct, limit = 4) {
        return productManager.products
            .filter(product => 
                product.id !== currentProduct.id && 
                product.category === currentProduct.category
            )
            .slice(0, limit);
    }
}

// Initialize category manager
const categoryManager = new CategoryManager();

// Update product manager to work with categories
ProductManager.prototype.getProductsByCategory = function(category, subcategory = '') {
    return this.products.filter(product => {
        let matches = product.category === category;
        if (subcategory && product.subcategory) {
            matches = matches && product.subcategory.toLowerCase() === subcategory.toLowerCase();
        }
        return matches;
    });
};

// Add sample products with proper categories
ProductManager.prototype.generateSampleProducts = function() {
    return [
        // Men's Shoes
        {
            id: 1,
            name: "Zawadi Air Max 2024",
            price: 129.99,
            category: "men",
            subcategory: "shoes",
            type: "Running",
            description: "Premium running shoes with advanced cushioning technology for maximum comfort and performance. Features breathable mesh upper and durable rubber outsole.",
            sizes: ["8", "9", "10", "11", "12"],
            colors: ["Black", "White", "Blue"],
            brand: "Zawadi",
            rating: 4.5,
            featured: true,
            inStock: true,
            isBestseller: true,
            images: ["shoe-black.jpg", "shoe-white.jpg"],
            features: ["Air cushioning", "Breathable mesh", "Durable outsole", "Lightweight"],
            specifications: {
                material: "Mesh & Synthetic",
                weight: "280g",
                closure: "Lace-up"
            }
        },
        // Men's Clothing
        {
            id: 2,
            name: "Men's Training Hoodie",
            price: 59.99,
            category: "men",
            subcategory: "clothing",
            type: "Hoodies",
            description: "Warm and comfortable hoodie perfect for training sessions. Made with moisture-wicking fabric to keep you dry.",
            sizes: ["S", "M", "L", "XL", "XXL"],
            colors: ["Black", "Grey", "Navy"],
            brand: "Zawadi",
            rating: 4.3,
            featured: true,
            inStock: true,
            isBestseller: true
        },
        // Women's Shoes
        {
            id: 3,
            name: "Women's Running Shoes",
            price: 119.99,
            category: "women",
            subcategory: "shoes",
            type: "Running",
            description: "Lightweight running shoes designed for women with enhanced cushioning and support.",
            sizes: ["6", "7", "8", "9"],
            colors: ["Pink", "White", "Purple"],
            brand: "Zawadi",
            rating: 4.7,
            featured: true,
            inStock: true
        },
        // Women's Clothing
        {
            id: 4,
            name: "Women's Training Leggings",
            price: 49.99,
            category: "women",
            subcategory: "clothing",
            type: "Leggings",
            description: "High-performance leggings with moisture-wicking fabric and four-way stretch for maximum mobility.",
            sizes: ["XS", "S", "M", "L"],
            colors: ["Black", "Blue", "Green"],
            brand: "Zawadi",
            rating: 4.6,
            featured: true,
            inStock: true,
            isBestseller: true
        },
        // Kids Shoes
        {
            id: 5,
            name: "Kids Sports T-Shirt",
            price: 24.99,
            category: "kids",
            subcategory: "clothing",
            type: "T-Shirts",
            description: "Comfortable and durable t-shirt perfect for active kids. Made with soft, breathable cotton.",
            sizes: ["XS", "S", "M", "L"],
            colors: ["Red", "Blue", "Yellow"],
            brand: "Zawadi",
            rating: 4.8,
            featured: true,
            inStock: true
        },
        // Sports Equipment
        {
            id: 6,
            name: "Pro Basketball Shoes",
            price: 149.99,
            category: "sport",
            subcategory: "footwear",
            type: "Basketball",
            description: "Professional basketball shoes with superior grip and ankle support for competitive play.",
            sizes: ["8", "9", "10", "11", "12", "13"],
            colors: ["White", "Black", "Red"],
            brand: "Zawadi Pro",
            rating: 4.8,
            featured: false,
            inStock: true
        },
        // Add more products for each category...
        {
            id: 7,
            name: "Men's Running Shorts",
            price: 39.99,
            category: "men",
            subcategory: "clothing",
            type: "Shorts",
            description: "Lightweight running shorts with built-in liner and multiple pockets for essentials.",
            sizes: ["S", "M", "L", "XL"],
            colors: ["Black", "Grey", "Blue"],
            brand: "Zawadi",
            rating: 4.4,
            featured: false,
            inStock: true
        },
        {
            id: 8,
            name: "Women's Yoga Mat",
            price: 34.99,
            category: "women",
            subcategory: "accessories",
            type: "Yoga Mats",
            description: "Non-slip yoga mat with excellent cushioning for comfortable practice sessions.",
            colors: ["Purple", "Teal", "Pink"],
            brand: "Zawadi",
            rating: 4.9,
            featured: true,
            inStock: true
        }
    ];
};