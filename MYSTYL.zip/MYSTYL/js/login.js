// Login Page Functionality
class LoginManager {
    constructor() {
        this.isLoading = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadBrandSettings();
        this.setupAdminAccess();
    }

    setupEventListeners() {
        // Login form submission
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Password visibility toggle
        const togglePassword = document.getElementById('togglePassword');
        if (togglePassword) {
            togglePassword.addEventListener('click', () => this.togglePasswordVisibility());
        }

        // Social login buttons
        document.querySelectorAll('.btn-social').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleSocialLogin(e));
        });

        // Admin access
        const adminBtn = document.getElementById('adminAccessBtn');
        if (adminBtn) {
            adminBtn.addEventListener('click', () => this.showAdminModal());
        }

        // Admin modal
        const adminModal = document.getElementById('adminModal');
        const closeModal = document.getElementById('closeAdminModal');
        const cancelBtn = document.getElementById('cancelAdminBtn');
        const adminForm = document.getElementById('adminSettingsForm');

        if (closeModal) {
            closeModal.addEventListener('click', () => this.hideAdminModal());
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.hideAdminModal());
        }

        if (adminForm) {
            adminForm.addEventListener('submit', (e) => this.handleAdminSettings(e));
        }

        // Close modal on outside click
        if (adminModal) {
            adminModal.addEventListener('click', (e) => {
                if (e.target === adminModal) {
                    this.hideAdminModal();
                }
            });
        }
    }

    handleLogin(e) {
        e.preventDefault();
        
        if (this.isLoading) return;

        const formData = new FormData(e.target);
        const email = formData.get('email');
        const password = formData.get('password');
        const rememberMe = document.getElementById('rememberMe').checked;

        // Validate inputs
        if (!this.validateEmail(email)) {
            this.showError('Please enter a valid email address');
            return;
        }

        if (!password) {
            this.showError('Please enter your password');
            return;
        }

        this.setLoading(true);

        // Simulate API call
        setTimeout(() => {
            this.setLoading(false);
            
            // Check for admin login
            if (email === 'admin@zawadi.com' && password === 'admin123') {
                this.showSuccess('Welcome back, Admin!');
                setTimeout(() => {
                    window.location.href = 'admin-dashboard.html';
                }, 1000);
                return;
            }

            // Regular user login simulation
            if (email && password) {
                this.showSuccess('Login successful! Redirecting...');
                setTimeout(() => {
                    window.location.href = 'account.html';
                }, 1500);
            } else {
                this.showError('Invalid email or password');
            }
        }, 2000);
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    togglePasswordVisibility() {
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.querySelector('#togglePassword i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            toggleIcon.className = 'fas fa-eye';
        }
    }

    handleSocialLogin(e) {
        e.preventDefault();
        const platform = e.target.closest('.btn-social').classList.contains('btn-google') ? 'Google' : 'Facebook';
        
        this.showInfo(`Redirecting to ${platform} login...`);
        // In a real app, this would redirect to OAuth flow
    }

    setLoading(loading) {
        this.isLoading = loading;
        const loginBtn = document.getElementById('loginBtn');
        
        if (loading) {
            loginBtn.classList.add('loading');
            loginBtn.disabled = true;
        } else {
            loginBtn.classList.remove('loading');
            loginBtn.disabled = false;
        }
    }

    showError(message) {
        this.showToast(message, 'error');
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showInfo(message) {
        this.showToast(message, 'info');
    }

    showToast(message, type = 'info') {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${this.getToastIcon(type)}"></i>
            <span>${message}</span>
        `;

        // Add to container or create one
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }

        container.appendChild(toast);

        // Remove after delay
        setTimeout(() => {
            toast.remove();
        }, 4000);
    }

    getToastIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            info: 'info-circle',
            warning: 'exclamation-triangle'
        };
        return icons[type] || 'info-circle';
    }

    // Admin Functionality
    setupAdminAccess() {
        // Show admin access button on triple click (hidden feature)
        let clickCount = 0;
        let lastClick = 0;
        
        document.addEventListener('click', (e) => {
            const currentTime = new Date().getTime();
            
            if (currentTime - lastClick > 1000) {
                clickCount = 0;
            }
            
            clickCount++;
            lastClick = currentTime;
            
            if (clickCount === 3) {
                this.showAdminAccessButton();
                clickCount = 0;
            }
        });
    }

    showAdminAccessButton() {
        const adminAccess = document.querySelector('.admin-access');
        if (adminAccess) {
            adminAccess.style.display = 'block';
            this.showInfo('Admin access unlocked');
        }
    }

    showAdminModal() {
        const modal = document.getElementById('adminModal');
        if (modal) {
            modal.classList.add('active');
            this.loadCurrentBrandSettings();
        }
    }

    hideAdminModal() {
        const modal = document.getElementById('adminModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    loadCurrentBrandSettings() {
        // Load current settings from localStorage or defaults
        const brandName = localStorage.getItem('brandName') || 'ZAWADI';
        const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
        const logoChar = localStorage.getItem('logoChar') || 'Z';

        document.getElementById('companyName').value = brandName;
        document.getElementById('companyTagline').value = brandTagline;
        document.getElementById('logoCharacter').value = logoChar;
    }

    handleAdminSettings(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const companyName = formData.get('companyName');
        const companyTagline = formData.get('companyTagline');
        const logoCharacter = formData.get('logoCharacter');

        // Validate inputs
        if (!companyName.trim()) {
            this.showError('Company name is required');
            return;
        }

        if (!logoCharacter.trim()) {
            this.showError('Logo character is required');
            return;
        }

        // Save to localStorage
        localStorage.setItem('brandName', companyName);
        localStorage.setItem('brandTagline', companyTagline);
        localStorage.setItem('logoChar', logoCharacter);

        // Update the page in real-time
        this.updateBrandDisplay();

        this.showSuccess('Brand settings updated successfully!');
        this.hideAdminModal();
    }

    loadBrandSettings() {
        this.updateBrandDisplay();
    }

    updateBrandDisplay() {
        // Update all brand-related elements on the page
        const brandName = localStorage.getItem('brandName') || 'ZAWADI';
        const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
        const logoChar = localStorage.getItem('logoChar') || 'Z';

        // Update page title
        document.title = document.title.replace(/ZAWADI/g, brandName);

        // Update all brand name elements
        document.querySelectorAll('[data-brand-name]').forEach(element => {
            element.textContent = brandName;
        });

        // Update all brand tagline elements
        document.querySelectorAll('[data-brand-tagline]').forEach(element => {
            element.textContent = brandTagline;
        });

        // Update all logo characters
        document.querySelectorAll('[data-brand-logo-char]').forEach(element => {
            element.textContent = logoChar;
        });

        // Update admin form inputs if they exist
        const nameInput = document.querySelector('[data-brand-name-input]');
        const taglineInput = document.querySelector('[data-brand-tagline-input]');
        const logoInput = document.querySelector('[data-brand-logo-input]');

        if (nameInput) nameInput.value = brandName;
        if (taglineInput) taglineInput.value = brandTagline;
        if (logoInput) logoInput.value = logoChar;
    }
}

// Initialize login manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LoginManager();
});

// Utility function to update brand across all pages
function updateGlobalBrandSettings() {
    const brandName = localStorage.getItem('brandName') || 'ZAWADI';
    const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
    const logoChar = localStorage.getItem('logoChar') || 'Z';

    // This function would be called on every page load
    document.querySelectorAll('[data-brand-name]').forEach(el => {
        el.textContent = brandName;
    });
    document.querySelectorAll('[data-brand-tagline]').forEach(el => {
        el.textContent = brandTagline;
    });
    document.querySelectorAll('[data-brand-logo-char]').forEach(el => {
        el.textContent = logoChar;
    });
}

// Call this on every page to ensure brand consistency
updateGlobalBrandSettings();