// Email Notification System
class EmailSystem {
    constructor() {
        this.templates = this.loadTemplates();
        this.settings = this.loadSettings();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadEmailHistory();
    }

    loadTemplates() {
        return {
            purchaseConfirmation: {
                id: 'purchase-confirmation',
                name: 'Purchase Confirmation',
                subject: 'Order Confirmation - {{order_number}}',
                triggers: ['order_placed'],
                recipients: ['customer'],
                enabled: true
            },
            orderShipped: {
                id: 'order-shipped',
                name: 'Order Shipped',
                subject: 'Your Order Has Shipped! - {{order_number}}',
                triggers: ['order_shipped'],
                recipients: ['customer'],
                enabled: true
            },
            orderDelivered: {
                id: 'order-delivered',
                name: 'Order Delivered',
                subject: 'Your Order Has Been Delivered! - {{order_number}}',
                triggers: ['order_delivered'],
                recipients: ['customer'],
                enabled: true
            },
            brokerCommission: {
                id: 'broker-commission',
                name: 'Broker Commission',
                subject: 'Commission Earned - {{commission_amount}}',
                triggers: ['commission_earned'],
                recipients: ['broker'],
                enabled: true
            },
            brokerWelcome: {
                id: 'broker-welcome',
                name: 'Broker Welcome',
                subject: 'Welcome to {{brand_name}} Broker Program!',
                triggers: ['broker_registered'],
                recipients: ['broker'],
                enabled: true
            },
            customerWelcome: {
                id: 'customer-welcome',
                name: 'Customer Welcome',
                subject: 'Welcome to {{brand_name}}!',
                triggers: ['customer_registered'],
                recipients: ['customer'],
                enabled: true
            }
        };
    }

    loadSettings() {
        return Utils.loadFromStorage('emailSettings') || {
            enabled: true,
            sendToCustomers: true,
            sendToBrokers: true,
            adminNotifications: true,
            testMode: false,
            testEmail: 'test@example.com'
        };
    }

    setupEventListeners() {
        // Listen for system events
        window.addEventListener('orderPlaced', (e) => this.handleOrderPlaced(e.detail));
        window.addEventListener('orderShipped', (e) => this.handleOrderShipped(e.detail));
        window.addEventListener('orderDelivered', (e) => this.handleOrderDelivered(e.detail));
        window.addEventListener('commissionEarned', (e) => this.handleCommissionEarned(e.detail));
        window.addEventListener('userRegistered', (e) => this.handleUserRegistered(e.detail));
    }

    // Event Handlers
    handleOrderPlaced(orderData) {
        if (this.settings.sendToCustomers && this.templates.purchaseConfirmation.enabled) {
            this.sendPurchaseConfirmation(orderData);
        }
        
        if (this.settings.adminNotifications) {
            this.sendAdminNotification('new_order', orderData);
        }
    }

    handleOrderShipped(orderData) {
        if (this.settings.sendToCustomers && this.templates.orderShipped.enabled) {
            this.sendOrderShipped(orderData);
        }
    }

    handleOrderDelivered(orderData) {
        if (this.settings.sendToCustomers && this.templates.orderDelivered.enabled) {
            this.sendOrderDelivered(orderData);
        }
    }

    handleCommissionEarned(commissionData) {
        if (this.settings.sendToBrokers && this.templates.brokerCommission.enabled) {
            this.sendBrokerCommission(commissionData);
        }
    }

    handleUserRegistered(userData) {
        if (userData.type === 'broker' && this.templates.brokerWelcome.enabled) {
            this.sendBrokerWelcome(userData);
        } else if (userData.type === 'customer' && this.templates.customerWelcome.enabled) {
            this.sendCustomerWelcome(userData);
        }
    }

    // Email Sending Methods
    async sendPurchaseConfirmation(orderData) {
        const template = await this.loadTemplate('purchase-confirmation');
        const htmlContent = this.replacePlaceholders(template, {
            order_number: orderData.orderNumber,
            customer_name: orderData.customerName,
            order_date: orderData.orderDate,
            order_total: orderData.total,
            items: orderData.items,
            shipping_address: orderData.shippingAddress,
            brand_name: window.zawadiApp?.brandConfig?.name || 'MYSTYL'
        });

        this.sendEmail({
            to: orderData.customerEmail,
            subject: `Order Confirmation - ${orderData.orderNumber}`,
            html: htmlContent,
            type: 'purchase_confirmation'
        });
    }

    async sendOrderShipped(orderData) {
        const template = await this.loadTemplate('order-shipped');
        const htmlContent = this.replacePlaceholders(template, {
            order_number: orderData.orderNumber,
            customer_name: orderData.customerName,
            tracking_number: orderData.trackingNumber,
            tracking_url: orderData.trackingUrl,
            estimated_delivery: orderData.estimatedDelivery,
            brand_name: window.zawadiApp?.brandConfig?.name || 'MYSTYL'
        });

        this.sendEmail({
            to: orderData.customerEmail,
            subject: `Your Order Has Shipped! - ${orderData.orderNumber}`,
            html: htmlContent,
            type: 'order_shipped'
        });
    }

    async sendOrderDelivered(orderData) {
        const template = await this.loadTemplate('order-delivered');
        const htmlContent = this.replacePlaceholders(template, {
            order_number: orderData.orderNumber,
            customer_name: orderData.customerName,
            delivery_date: orderData.deliveryDate,
            brand_name: window.zawadiApp?.brandConfig?.name || 'MYSTYL'
        });

        this.sendEmail({
            to: orderData.customerEmail,
            subject: `Your Order Has Been Delivered! - ${orderData.orderNumber}`,
            html: htmlContent,
            type: 'order_delivered'
        });
    }

    async sendBrokerCommission(commissionData) {
        const template = await this.loadTemplate('broker-commission');
        const htmlContent = this.replacePlaceholders(template, {
            broker_name: commissionData.brokerName,
            commission_amount: commissionData.amount,
            order_number: commissionData.orderNumber,
            customer_name: commissionData.customerName,
            total_earnings: commissionData.totalEarnings,
            brand_name: window.zawadiApp?.brandConfig?.name || 'MYSTYL'
        });

        this.sendEmail({
            to: commissionData.brokerEmail,
            subject: `Commission Earned - £${commissionData.amount}`,
            html: htmlContent,
            type: 'broker_commission'
        });
    }

    async sendBrokerWelcome(userData) {
        const template = await this.loadTemplate('broker-welcome');
        const htmlContent = this.replacePlaceholders(template, {
            broker_name: userData.name,
            broker_code: userData.brokerCode,
            commission_rate: userData.commissionRate,
            referral_link: userData.referralLink,
            brand_name: window.zawadiApp?.brandConfig?.name || 'MYSTYL'
        });

        this.sendEmail({
            to: userData.email,
            subject: `Welcome to ${window.zawadiApp?.brandConfig?.name || 'MYSTYL'} Broker Program!`,
            html: htmlContent,
            type: 'broker_welcome'
        });
    }

    async sendCustomerWelcome(userData) {
        const template = await this.loadTemplate('customer-welcome');
        const htmlContent = this.replacePlaceholders(template, {
            customer_name: userData.name,
            brand_name: window.zawadiApp?.brandConfig?.name || 'MYSTYL'
        });

        this.sendEmail({
            to: userData.email,
            subject: `Welcome to ${window.zawadiApp?.brandConfig?.name || 'MYSTYL'}!`,
            html: htmlContent,
            type: 'customer_welcome'
        });
    }

    async sendAdminNotification(type, data) {
        const adminEmail = 'admin@mystyl.com'; // Would come from settings
        let subject = '';
        let message = '';

        switch (type) {
            case 'new_order':
                subject = `New Order Received - ${data.orderNumber}`;
                message = `New order placed by ${data.customerName} for £${data.total}`;
                break;
            case 'low_stock':
                subject = 'Low Stock Alert';
                message = `Product ${data.productName} is running low on stock (${data.stockLevel} remaining)`;
                break;
            case 'high_commission':
                subject = 'High Commission Payout';
                message = `Broker ${data.brokerName} earned £${data.amount} in commissions this month`;
                break;
        }

        this.sendEmail({
            to: adminEmail,
            subject: subject,
            html: this.generateAdminNotificationHTML(type, data),
            type: 'admin_notification'
        });
    }

    // Template Management
    async loadTemplate(templateName) {
        try {
            // In a real app, this would fetch from server
            // For now, we'll use embedded templates or localStorage
            const savedTemplate = Utils.loadFromStorage(`email_template_${templateName}`);
            if (savedTemplate) {
                return savedTemplate;
            }
            
            // Fallback to default templates
            return this.getDefaultTemplate(templateName);
        } catch (error) {
            console.error('Failed to load template:', error);
            return this.getDefaultTemplate(templateName);
        }
    }

    getDefaultTemplate(templateName) {
        const defaultTemplates = {
            'purchase-confirmation': `
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                        .header { background: #000; color: white; padding: 20px; text-align: center; }
                        .content { background: #f9f9f9; padding: 20px; }
                        .order-details { background: white; padding: 15px; margin: 15px 0; border-left: 4px solid #000; }
                        .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>{{brand_name}}</h1>
                            <h2>Order Confirmation</h2>
                        </div>
                        <div class="content">
                            <p>Hi {{customer_name}},</p>
                            <p>Thank you for your order! We're getting it ready to be shipped.</p>
                            
                            <div class="order-details">
                                <h3>Order Details</h3>
                                <p><strong>Order Number:</strong> {{order_number}}</p>
                                <p><strong>Order Date:</strong> {{order_date}}</p>
                                <p><strong>Total Amount:</strong> £{{order_total}}</p>
                            </div>
                            
                            <p>We'll notify you when your order ships.</p>
                            <p>Thank you for choosing {{brand_name}}!</p>
                        </div>
                        <div class="footer">
                            <p>&copy; 2024 {{brand_name}}. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            `,
            'order-shipped': `
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                        .header { background: #000; color: white; padding: 20px; text-align: center; }
                        .content { background: #f9f9f9; padding: 20px; }
                        .tracking-info { background: white; padding: 15px; margin: 15px 0; border-left: 4px solid #007bff; }
                        .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>{{brand_name}}</h1>
                            <h2>Your Order Has Shipped!</h2>
                        </div>
                        <div class="content">
                            <p>Hi {{customer_name}},</p>
                            <p>Great news! Your order has been shipped and is on its way to you.</p>
                            
                            <div class="tracking-info">
                                <h3>Tracking Information</h3>
                                <p><strong>Order Number:</strong> {{order_number}}</p>
                                <p><strong>Tracking Number:</strong> {{tracking_number}}</p>
                                <p><strong>Estimated Delivery:</strong> {{estimated_delivery}}</p>
                                <p><a href="{{tracking_url}}">Track Your Package</a></p>
                            </div>
                            
                            <p>We hope you love your purchase!</p>
                        </div>
                        <div class="footer">
                            <p>&copy; 2024 {{brand_name}}. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            `,
            'broker-commission': `
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                        .header { background: #000; color: white; padding: 20px; text-align: center; }
                        .content { background: #f9f9f9; padding: 20px; }
                        .commission-details { background: white; padding: 15px; margin: 15px 0; border-left: 4px solid #28a745; }
                        .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>{{brand_name}} Broker Program</h1>
                            <h2>Commission Earned!</h2>
                        </div>
                        <div class="content">
                            <p>Hi {{broker_name}},</p>
                            <p>Congratulations! You've earned a commission from a recent sale.</p>
                            
                            <div class="commission-details">
                                <h3>Commission Details</h3>
                                <p><strong>Commission Amount:</strong> £{{commission_amount}}</p>
                                <p><strong>Order Number:</strong> {{order_number}}</p>
                                <p><strong>Customer:</strong> {{customer_name}}</p>
                                <p><strong>Total Earnings:</strong> £{{total_earnings}}</p>
                            </div>
                            
                            <p>Keep up the great work! Your commissions will be paid out according to our payment schedule.</p>
                        </div>
                        <div class="footer">
                            <p>&copy; 2024 {{brand_name}} Broker Program. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            `
        };

        return defaultTemplates[templateName] || '<p>Email template not found.</p>';
    }

    replacePlaceholders(template, data) {
        let result = template;
        for (const [key, value] of Object.entries(data)) {
            const placeholder = new RegExp(`{{${key}}}`, 'g');
            result = result.replace(placeholder, value);
        }
        return result;
    }

    generateAdminNotificationHTML(type, data) {
        // Simple HTML for admin notifications
        return `
            <!DOCTYPE html>
            <html>
            <body>
                <h2>Admin Notification - ${type}</h2>
                <pre>${JSON.stringify(data, null, 2)}</pre>
            </body>
            </html>
        `;
    }

    // Email Sending (Simulated)
    async sendEmail(emailData) {
        if (this.settings.testMode) {
            emailData.to = this.settings.testEmail;
        }

        // Simulate email sending
        console.log('Sending email:', emailData);

        // Store in email history
        this.storeEmailHistory(emailData);

        // In a real application, you would:
        // 1. Send to your backend API
        // 2. Use a service like SendGrid, Mailgun, etc.
        // 3. Handle errors and retries

        // Simulate API call
        try {
            // This would be your actual email sending code
            // await fetch('/api/send-email', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(emailData)
            // });

            // For demo purposes, we'll just log success
            console.log('Email sent successfully to:', emailData.to);
            
            // Show notification
            if (window.zawadiApp) {
                window.zawadiApp.showToast('Email notification sent', 'success');
            }

        } catch (error) {
            console.error('Failed to send email:', error);
            if (window.zawadiApp) {
                window.zawadiApp.showToast('Failed to send email', 'error');
            }
        }
    }

    storeEmailHistory(emailData) {
        const history = Utils.loadFromStorage('emailHistory') || [];
        history.unshift({
            ...emailData,
            sentAt: new Date().toISOString(),
            id: Date.now().toString()
        });
        
        // Keep only last 100 emails
        if (history.length > 100) {
            history.pop();
        }
        
        Utils.saveToStorage('emailHistory', history);
    }

    loadEmailHistory() {
        return Utils.loadFromStorage('emailHistory') || [];
    }

    // Settings Management
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
        Utils.saveToStorage('emailSettings', this.settings);
    }

    updateTemplate(templateId, updates) {
        if (this.templates[templateId]) {
            this.templates[templateId] = { ...this.templates[templateId], ...updates };
            Utils.saveToStorage(`email_template_${templateId}`, this.templates[templateId]);
        }
    }

    // Test Methods
    async testEmail(templateId, testData) {
        const template = await this.loadTemplate(templateId);
        const htmlContent = this.replacePlaceholders(template, testData);
        
        this.sendEmail({
            to: this.settings.testEmail,
            subject: `TEST: ${this.templates[templateId]?.subject || 'Test Email'}`,
            html: htmlContent,
            type: 'test'
        });
    }

    // Get methods for UI
    getTemplates() {
        return this.templates;
    }

    getSettings() {
        return this.settings;
    }

    getEmailHistory() {
        return this.loadEmailHistory();
    }
}

// Initialize email system
window.emailSystem = new EmailSystem();

// Export for use in other files
window.EmailSystem = EmailSystem;
