// Email Scheduling System
class EmailScheduler {
    constructor() {
        this.scheduledEmails = this.loadScheduledEmails();
        this.sequences = this.loadSequences();
        this.init();
    }

    init() {
        this.processScheduledEmails();
        this.setupIntervals();
    }

    setupIntervals() {
        // Check for scheduled emails every minute
        setInterval(() => {
            this.processScheduledEmails();
        }, 60000);

        // Process email sequences every hour
        setInterval(() => {
            this.processSequences();
        }, 3600000);
    }

    // Schedule a single email
    scheduleEmail(emailData, sendAt) {
        const scheduledEmail = {
            id: 'sched_' + Date.now().toString(),
            ...emailData,
            scheduledAt: new Date().toISOString(),
            sendAt: new Date(sendAt).toISOString(),
            status: 'scheduled'
        };

        this.scheduledEmails.push(scheduledEmail);
        this.saveScheduledEmails();
        
        return scheduledEmail.id;
    }

    // Create an email sequence
    createSequence(sequenceData) {
        const sequence = {
            id: 'seq_' + Date.now().toString(),
            name: sequenceData.name,
            triggers: sequenceData.triggers,
            steps: sequenceData.steps,
            enabled: true,
            createdAt: new Date().toISOString()
        };

        this.sequences.push(sequence);
        this.saveSequences();
        
        return sequence.id;
    }

    // Process scheduled emails
    async processScheduledEmails() {
        const now = new Date();
        const emailsToSend = this.scheduledEmails.filter(email => 
            email.status === 'scheduled' && 
            new Date(email.sendAt) <= now
        );

        for (const email of emailsToSend) {
            try {
                await window.emailSystem.sendEmail(email);
                email.status = 'sent';
                email.sentAt = new Date().toISOString();
            } catch (error) {
                email.status = 'failed';
                email.error = error.message;
                email.lastAttempt = new Date().toISOString();
            }
        }

        this.saveScheduledEmails();
    }

    // Process email sequences
    async processSequences() {
        for (const sequence of this.sequences) {
            if (!sequence.enabled) continue;

            // This would typically check for users who should receive sequence emails
            // For demo, we'll just log the processing
            console.log(`Processing sequence: ${sequence.name}`);
        }
    }

    // Pre-built sequences
    getPrebuiltSequences() {
        return {
            welcomeSequence: {
                name: 'Welcome Sequence',
                triggers: ['customer_registered'],
                steps: [
                    {
                        delay: 0,
                        template: 'customer-welcome',
                        subject: 'Welcome to {{brand_name}}!'
                    },
                    {
                        delay: 24 * 60 * 60 * 1000, // 1 day
                        template: 'welcome-followup',
                        subject: 'Get Started with {{brand_name}}'
                    },
                    {
                        delay: 3 * 24 * 60 * 60 * 1000, // 3 days
                        template: 'first-purchase-offer',
                        subject: 'Special Offer Just For You!'
                    }
                ]
            },
            abandonedCart: {
                name: 'Abandoned Cart Recovery',
                triggers: ['cart_abandoned'],
                steps: [
                    {
                        delay: 1 * 60 * 60 * 1000, // 1 hour
                        template: 'cart-reminder-1',
                        subject: 'Forgot Something?'
                    },
                    {
                        delay: 24 * 60 * 60 * 1000, // 1 day
                        template: 'cart-reminder-2',
                        subject: 'Your Cart is Waiting!'
                    },
                    {
                        delay: 3 * 24 * 60 * 60 * 1000, // 3 days
                        template: 'cart-reminder-3',
                        subject: 'Last Chance - Special Offer!'
                    }
                ]
            },
            postPurchase: {
                name: 'Post-Purchase Follow-up',
                triggers: ['order_delivered'],
                steps: [
                    {
                        delay: 7 * 24 * 60 * 60 * 1000, // 7 days
                        template: 'product-review-request',
                        subject: 'How Do You Like Your Purchase?'
                    },
                    {
                        delay: 30 * 24 * 60 * 60 * 1000, // 30 days
                        template: 'reorder-reminder',
                        subject: 'Time to Restock?'
                    }
                ]
            }
        };
    }

    // Load scheduled emails from storage
    loadScheduledEmails() {
        return Utils.loadFromStorage('scheduledEmails') || [];
    }

    // Save scheduled emails to storage
    saveScheduledEmails() {
        Utils.saveToStorage('scheduledEmails', this.scheduledEmails);
    }

    // Load sequences from storage
    loadSequences() {
        return Utils.loadFromStorage('emailSequences') || [];
    }

    // Save sequences to storage
    saveSequences() {
        Utils.saveToStorage('emailSequences', this.sequences);
    }

    // Get scheduled emails by status
    getScheduledEmailsByStatus(status) {
        return this.scheduledEmails.filter(email => email.status === status);
    }

    // Cancel a scheduled email
    cancelScheduledEmail(emailId) {
        this.scheduledEmails = this.scheduledEmails.filter(email => 
            email.id !== emailId
        );
        this.saveScheduledEmails();
    }

    // Pause a sequence
    pauseSequence(sequenceId) {
        const sequence = this.sequences.find(s => s.id === sequenceId);
        if (sequence) {
            sequence.enabled = false;
            this.saveSequences();
        }
    }

    // Resume a sequence
    resumeSequence(sequenceId) {
        const sequence = this.sequences.find(s => s.id === sequenceId);
        if (sequence) {
            sequence.enabled = true;
            this.saveSequences();
        }
    }

    // Get statistics
    getSchedulerStats() {
        const scheduled = this.getScheduledEmailsByStatus('scheduled').length;
        const sent = this.getScheduledEmailsByStatus('sent').length;
        const failed = this.getScheduledEmailsByStatus('failed').length;
        const activeSequences = this.sequences.filter(s => s.enabled).length;

        return {
            scheduled,
            sent,
            failed,
            activeSequences,
            totalSequences: this.sequences.length
        };
    }
}

// Initialize email scheduler
window.emailScheduler = new EmailScheduler();
