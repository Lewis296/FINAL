// Product Details Functionality
class ProductDetails {
    constructor() {
        this.selectedSize = null;
        this.selectedColor = 'black';
        this.quantity = 1;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadRelatedProducts();
        this.updateBranding();
        this.setupBrandSync();
    }

    setupEventListeners() {
        // Size selection
        document.querySelectorAll('.size-option input').forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.selectedSize = e.target.value;
                this.updateAddToBagButton();
                this.hideFitFinderMessage();
            });
        });

        // Color selection
        document.querySelectorAll('.color-option').forEach(option => {
            option.addEventListener('click', (e) => {
                document.querySelectorAll('.color-option').forEach(opt => {
                    opt.classList.remove('active');
                });
                option.classList.add('active');
                this.selectedColor = option.dataset.color;
            });
        });

        // Add to bag
        document.querySelector('.add-to-bag-btn').addEventListener('click', () => {
            this.addToBag();
        });

        // Image thumbnails
        document.querySelectorAll('.thumbnail').forEach(thumb => {
            thumb.addEventListener('click', () => {
                document.querySelectorAll('.thumbnail').forEach(t => {
                    t.classList.remove('active');
                });
                thumb.classList.add('active');
                // In a real app, this would change the main image
            });
        });
    }

    updateAddToBagButton() {
        const button = document.querySelector('.add-to-bag-btn');
        if (this.selectedSize) {
            button.disabled = false;
            button.innerHTML = `<i class="fas fa-shopping-bag"></i> ADD TO BAG - £70.00`;
        } else {
            button.disabled = true;
            button.innerHTML = `<i class="fas fa-shopping-bag"></i> PLEASE SELECT A SIZE`;
        }
    }

    hideFitFinderMessage() {
        const message = document.querySelector('.fit-finder-message');
        if (message) {
            message.style.display = 'none';
        }
    }

    addToBag() {
        if (!this.selectedSize) {
            this.showToast('Please select a size', 'error');
            return;
        }

        const product = {
            id: 'RUN-PRO-001',
            name: 'Premium Runner Pro',
            price: 70.00,
            image: 'fas fa-shoe-prints',
            size: this.selectedSize,
            color: this.selectedColor
        };

        if (window.zawadiApp) {
            window.zawadiApp.addToCart(product, this.quantity, this.selectedSize);
        } else {
            this.showToast('Product added to bag!', 'success');
        }
    }

    loadRelatedProducts() {
        const relatedProducts = [
            {
                id: 'RUN-LITE-002',
                name: 'Urban Lite Runner',
                price: 55.00,
                image: 'fas fa-running',
                category: 'Sneakers'
            },
            {
                id: 'CAS-PRO-003',
                name: 'Classic Casual Pro',
                price: 65.00,
                image: 'fas fa-shoe-prints',
                category: 'Sneakers'
            },
            {
                id: 'TRA-MAX-004',
                name: 'Trail Max Adventure',
                price: 80.00,
                image: 'fas fa-hiking',
                category: 'Outdoor'
            },
            {
                id: 'BAS-TEE-005',
                name: 'Essential Cotton Tee',
                price: 25.00,
                image: 'fas fa-tshirt',
                category: 'Apparel'
            }
        ];

        const grid = document.querySelector('.related-products .products-grid');
        if (grid) {
            grid.innerHTML = relatedProducts.map(product => `
                <div class="product-card" data-product-id="${product.id}">
                    <div class="product-image">
                        <i class="${product.image}"></i>
                        <div class="product-actions">
                            <button class="btn-icon quick-view" title="Quick View">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn-icon add-to-wishlist" title="Add to Wishlist">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>${product.name}</h3>
                        <div class="product-meta">
                            <span class="price">£${product.price.toFixed(2)}</span>
                            <div class="rating">
                                <i class="fas fa-star"></i>
                                <span>4.8</span>
                            </div>
                        </div>
                        <button class="btn btn-outline btn-sm add-to-cart-btn">Add to Cart</button>
                    </div>
                </div>
            `).join('');

            // Add event listeners to related product buttons
            grid.querySelectorAll('.add-to-cart-btn').forEach((btn, index) => {
                btn.addEventListener('click', () => {
                    const product = relatedProducts[index];
                    if (window.zawadiApp) {
                        window.zawadiApp.addToCart(product);
                    } else {
                        this.showToast(`${product.name} added to cart!`, 'success');
                    }
                });
            });
        }
    }

    setupBrandSync() {
        // Listen for storage events (works across tabs)
        window.addEventListener('storage', (e) => {
            if (e.key === 'zawadiBrandConfig') {
                this.updateBranding();
            }
        });

        // Poll for changes every 2 seconds
        setInterval(() => {
            this.checkForBrandUpdates();
        }, 2000);
    }

    checkForBrandUpdates() {
        const latestConfig = JSON.parse(localStorage.getItem('zawadiBrandConfig'));
        if (latestConfig) {
            this.updateBranding();
        }
    }

    updateBranding() {
        const brandConfig = JSON.parse(localStorage.getItem('zawadiBrandConfig')) || {
            name: 'MYSTYL',
            tagline: 'Premium African-inspired Sportswear',
            logoChar: 'M'
        };

        // Update all branded elements
        document.querySelectorAll('[data-brand-name]').forEach(el => {
            if (el.tagName === 'TITLE') {
                el.textContent = el.textContent.replace(/MYSTYL/g, brandConfig.name);
            } else {
                el.textContent = brandConfig.name;
            }
        });

        document.querySelectorAll('[data-brand-tagline]').forEach(el => {
            el.textContent = brandConfig.tagline;
        });

        document.querySelectorAll('[data-brand-logo-char]').forEach(el => {
            el.textContent = brandConfig.logoChar;
        });

        document.querySelectorAll('[data-broker-program]').forEach(el => {
            if (el.textContent.includes('Broker Program')) {
                el.textContent = `${brandConfig.name} Broker Program`;
            }
        });

        // Update loyalty program text
        const loyaltyInfo = document.querySelector('.loyalty-program strong');
        if (loyaltyInfo) {
            loyaltyInfo.textContent = brandConfig.name;
        }

        // Update any elements with brand name in text
        this.updateDynamicBrandReferences();
    }

    updateDynamicBrandReferences() {
        const elements = document.querySelectorAll('body *');
        elements.forEach(el => {
            if (el.children.length === 0 && el.textContent) {
                const text = el.textContent;
                if (text.includes('MYSTYL')) {
                    const brandConfig = JSON.parse(localStorage.getItem('zawadiBrandConfig')) || { name: 'MYSTYL' };
                    el.textContent = text.replace(/MYSTYL/g, brandConfig.name);
                }
            }
        });
    }

    showToast(message, type = 'info') {
        if (window.zawadiApp) {
            window.zawadiApp.showToast(message, type);
        } else {
            // Fallback toast
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: var(--card-bg);
                color: var(--text-color);
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: var(--shadow);
                z-index: 1000;
                border-left: 4px solid ${type === 'success' ? '#10b981' : '#ef4444'};
            `;
            toast.textContent = message;
            document.body.appendChild(toast);
            
            setTimeout(() => toast.remove(), 3000);
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ProductDetails();
});