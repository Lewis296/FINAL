// Main Application Controller
class ZawadiApp {
    constructor() {
        this.cart = Utils.loadFromStorage('zawadiCart') || [];
        this.user = Utils.loadFromStorage('zawadiUser') || null;
        this.settings = Utils.loadFromStorage('zawadiSettings') || {
            theme: 'dark',
            currency: 'GBP',
            notifications: true
        };
        this.brandConfig = this.loadBrandConfig();
        this.init();
    }

    // Improved brand config loading with fallback
    loadBrandConfig() {
        const savedConfig = Utils.loadFromStorage('zawadiBrandConfig');
        if (savedConfig) {
            return savedConfig;
        }
        
        // Default brand configuration
        return {
            name: 'ZAWADI',
            tagline: 'Premium African-inspired Sportswear',
            logoChar: 'Z'
        };
    }

    async init() {
        this.setupEventListeners();
        this.updateCartCount();
        this.checkAuthState();
        this.applyTheme();
        this.updateBranding(); // Initial branding update
        this.setupBrandSync(); // Real-time sync
    }

    // Real-time brand synchronization
    setupBrandSync() {
        // Listen for storage events (works across tabs)
        window.addEventListener('storage', (e) => {
            if (e.key === 'zawadiBrandConfig') {
                console.log('Brand config updated from storage event');
                this.brandConfig = JSON.parse(e.newValue);
                this.updateBranding();
            }
        });

        // Poll for changes (works in same tab)
        this.startBrandPolling();
        
        // Also update immediately on load in case admin just changed it
        this.checkForBrandUpdates();
    }

    startBrandPolling() {
        // Check for brand updates every 2 seconds
        setInterval(() => {
            this.checkForBrandUpdates();
        }, 2000);
    }

    checkForBrandUpdates() {
        const latestConfig = Utils.loadFromStorage('zawadiBrandConfig');
        if (latestConfig && JSON.stringify(latestConfig) !== JSON.stringify(this.brandConfig)) {
            console.log('Brand config updated via polling');
            this.brandConfig = latestConfig;
            this.updateBranding();
        }
    }

    // Enhanced branding update
    updateBranding() {
        console.log('Updating branding with:', this.brandConfig);
        
        // Update all brand elements on the page
        const brandNameElements = document.querySelectorAll('[data-brand-name]');
        const brandTaglineElements = document.querySelectorAll('[data-brand-tagline]');
        const logoCharElements = document.querySelectorAll('[data-brand-logo-char]');
        const brokerElements = document.querySelectorAll('[data-broker-program]');
        
        // Update brand name elements
        brandNameElements.forEach(el => {
            if (el.tagName === 'TITLE') {
                const currentTitle = el.textContent;
                const newTitle = currentTitle.replace(/(ZAWADI|MYSTYL)/g, this.brandConfig.name);
                el.textContent = newTitle;
            } else {
                el.textContent = this.brandConfig.name;
            }
        });
        
        // Update tagline elements
        brandTaglineElements.forEach(el => {
            el.textContent = this.brandConfig.tagline;
        });
        
        // Update logo characters
        logoCharElements.forEach(el => {
            el.textContent = this.brandConfig.logoChar;
        });

        // Update broker program references
        brokerElements.forEach(el => {
            if (el.textContent.includes('Broker Program')) {
                el.textContent = `${this.brandConfig.name} Broker Program`;
            } else {
                el.textContent = this.brandConfig.name;
            }
        });

        // Update any elements with brand name in text
        this.updateDynamicBrandReferences();

        console.log('Branding update complete');
    }

    // Update elements that might contain brand name in their text
    updateDynamicBrandReferences() {
        const elements = document.querySelectorAll('body *');
        elements.forEach(el => {
            if (el.children.length === 0 && el.textContent) {
                const text = el.textContent;
                if (text.includes('ZAWADI') || text.includes('MYSTYL')) {
                    el.textContent = text.replace(/(ZAWADI|MYSTYL)/g, this.brandConfig.name);
                }
            }
        });
    }

    // Update brand configuration (for admin use)
    updateBrandConfig(newConfig) {
        this.brandConfig = { ...this.brandConfig, ...newConfig };
        Utils.saveToStorage('zawadiBrandConfig', this.brandConfig);
        this.updateBranding();
        
        // Force refresh across all tabs
        this.forceBrandRefresh();
    }

    forceBrandRefresh() {
        // Trigger a custom event that other tabs can listen for
        if (typeof Storage !== 'undefined') {
            localStorage.setItem('zawadiBrandRefresh', Date.now().toString());
        }
    }

    // Rest of your existing methods remain the same...
    setupEventListeners() {
        this.setupSearch();
        this.setupMobileMenu();
        this.setupThemeToggle();
    }

    setupSearch() {
        const searchBtn = document.querySelector('.search-btn');
        const searchInput = document.querySelector('.search-input');
        
        if (searchBtn && searchInput) {
            searchBtn.addEventListener('click', () => this.handleSearch());
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.handleSearch();
            });
        }
    }

    setupMobileMenu() {
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const sidebar = document.getElementById('sidebar');
        const closeSidebar = document.getElementById('closeSidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                sidebar.classList.toggle('active');
            });
        }

        if (closeSidebar && sidebar) {
            closeSidebar.addEventListener('click', () => {
                sidebar.classList.remove('active');
            });
        }

        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });
    }

    setupThemeToggle() {
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('change', () => {
                document.body.classList.toggle('dark-mode');
                localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
            });
        }
    }

    applyTheme() {
        const savedTheme = localStorage.getItem('theme');
        const themeToggle = document.getElementById('themeToggle');
        
        if (savedTheme) {
            document.body.classList.toggle('dark-mode', savedTheme === 'dark');
            if (themeToggle) {
                themeToggle.checked = savedTheme === 'dark';
            }
        }
    }

    // Search Handler
    handleSearch() {
        const searchInput = document.querySelector('.search-input');
        const query = searchInput?.value.trim();
        
        if (query) {
            window.location.href = `shop.html?search=${encodeURIComponent(query)}`;
        }
    }

    // Cart Management
    updateCartCount() {
        const cartIcons = document.querySelectorAll('.cart-count');
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        
        cartIcons.forEach(icon => {
            icon.textContent = totalItems;
            icon.style.display = totalItems > 0 ? 'flex' : 'none';
        });
    }

    addToCart(product, quantity = 1, size = null) {
        const existingItem = this.cart.find(item => 
            item.id === product.id && item.selectedSize === (size || product.sizes[0])
        );

        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.cart.push({
                ...product,
                quantity,
                selectedSize: size || product.sizes[0],
                addedAt: new Date().toISOString()
            });
        }

        Utils.saveToStorage('zawadiCart', this.cart);
        this.updateCartCount();
        this.showToast(`${product.name} added to cart!`, 'success');
    }

    removeFromCart(productId, size = null) {
        this.cart = this.cart.filter(item => 
            !(item.id === productId && item.selectedSize === size)
        );
        
        Utils.saveToStorage('zawadiCart', this.cart);
        this.updateCartCount();
        this.showToast('Item removed from cart', 'info');
    }

    updateCartQuantity(productId, quantity, size = null) {
        const item = this.cart.find(item => 
            item.id === productId && item.selectedSize === size
        );
        
        if (item) {
            if (quantity <= 0) {
                this.removeFromCart(productId, size);
            } else {
                item.quantity = quantity;
                Utils.saveToStorage('zawadiCart', this.cart);
                this.updateCartCount();
            }
        }
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    // Order Tracking System
    trackOrder(orderId) {
        const trackingSteps = [
            { status: 'ordered', label: 'Order Placed', description: 'Your order has been confirmed' },
            { status: 'processing', label: 'Processing', description: 'Preparing your items for shipment' },
            { status: 'shipped', label: 'Shipped', description: 'Your order is on the way' },
            { status: 'out_for_delivery', label: 'Out for Delivery', description: 'Your order will arrive today' },
            { status: 'delivered', label: 'Delivered', description: 'Order successfully delivered' }
        ];

        return trackingSteps;
    }

    getOrderStatus(orderId) {
        const statuses = ['ordered', 'processing', 'shipped', 'out_for_delivery', 'delivered'];
        const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
        return randomStatus;
    }

    // Authentication
    checkAuthState() {
        const authElements = document.querySelectorAll('[data-auth]');
        
        authElements.forEach(el => {
            if (this.user) {
                if (el.dataset.auth === 'guest') {
                    el.style.display = 'none';
                } else if (el.dataset.auth === 'user') {
                    el.style.display = 'block';
                    this.updateUserInfo(el);
                }
            } else {
                if (el.dataset.auth === 'guest') {
                    el.style.display = 'block';
                } else if (el.dataset.auth === 'user') {
                    el.style.display = 'none';
                }
            }
        });
    }

    updateUserInfo(element) {
        const placeholders = element.querySelectorAll('[data-user]');
        placeholders.forEach(placeholder => {
            const field = placeholder.dataset.user;
            if (this.user[field]) {
                placeholder.textContent = this.user[field];
            }
        });
    }

    // Utility Methods
    showToast(message, type = 'info', duration = 3000) {
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <span class="toast-message">${message}</span>
                <button class="toast-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        container.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('show');
        }, 100);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    // URL Helper
    getQueryParam(param) {
        return Utils.getQueryParam(param);
    }

    formatPrice(price) {
        return Utils.formatPrice(price);
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.zawadiApp = new ZawadiApp();
});

// Error Boundary
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    if (window.zawadiApp) {
        window.zawadiApp.showToast('Something went wrong. Please refresh the page.', 'error');
    }
});

// In the ZawadiApp constructor, add:
this.emailSystem = new EmailSystem();

// In the init method, add:
this.emailSystem.init();
// Login Page Functionality
class LoginManager {
    constructor() {
        this.isLoading = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadBrandSettings();
        this.setupAdminAccess();
    }

    setupEventListeners() {
        // Login form submission
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Password visibility toggle
        const togglePassword = document.getElementById('togglePassword');
        if (togglePassword) {
            togglePassword.addEventListener('click', () => this.togglePasswordVisibility());
        }

        // Social login buttons
        document.querySelectorAll('.btn-social').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleSocialLogin(e));
        });

        // Admin access
        const adminBtn = document.getElementById('adminAccessBtn');
        if (adminBtn) {
            adminBtn.addEventListener('click', () => this.showAdminModal());
        }

        // Admin modal
        const adminModal = document.getElementById('adminModal');
        const closeModal = document.getElementById('closeAdminModal');
        const cancelBtn = document.getElementById('cancelAdminBtn');
        const adminForm = document.getElementById('adminSettingsForm');

        if (closeModal) {
            closeModal.addEventListener('click', () => this.hideAdminModal());
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.hideAdminModal());
        }

        if (adminForm) {
            adminForm.addEventListener('submit', (e) => this.handleAdminSettings(e));
        }

        // Close modal on outside click
        if (adminModal) {
            adminModal.addEventListener('click', (e) => {
                if (e.target === adminModal) {
                    this.hideAdminModal();
                }
            });
        }
    }

    handleLogin(e) {
        e.preventDefault();
        
        if (this.isLoading) return;

        const formData = new FormData(e.target);
        const email = formData.get('email');
        const password = formData.get('password');
        const rememberMe = document.getElementById('rememberMe').checked;

        // Validate inputs
        if (!this.validateEmail(email)) {
            this.showError('Please enter a valid email address');
            return;
        }

        if (!password) {
            this.showError('Please enter your password');
            return;
        }

        this.setLoading(true);

        // Simulate API call
        setTimeout(() => {
            this.setLoading(false);
            
            // Check for admin login
            if (email === 'admin@zawadi.com' && password === 'admin123') {
                this.showSuccess('Welcome back, Admin!');
                setTimeout(() => {
                    window.location.href = 'admin-dashboard.html';
                }, 1000);
                return;
            }

            // Regular user login simulation
            if (email && password) {
                this.showSuccess('Login successful! Redirecting...');
                setTimeout(() => {
                    window.location.href = 'account.html';
                }, 1500);
            } else {
                this.showError('Invalid email or password');
            }
        }, 2000);
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    togglePasswordVisibility() {
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.querySelector('#togglePassword i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.className = 'fas fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            toggleIcon.className = 'fas fa-eye';
        }
    }

    handleSocialLogin(e) {
        e.preventDefault();
        const platform = e.target.closest('.btn-social').classList.contains('btn-google') ? 'Google' : 'Facebook';
        
        this.showInfo(`Redirecting to ${platform} login...`);
        // In a real app, this would redirect to OAuth flow
    }

    setLoading(loading) {
        this.isLoading = loading;
        const loginBtn = document.getElementById('loginBtn');
        
        if (loading) {
            loginBtn.classList.add('loading');
            loginBtn.disabled = true;
        } else {
            loginBtn.classList.remove('loading');
            loginBtn.disabled = false;
        }
    }

    showError(message) {
        this.showToast(message, 'error');
    }

    showSuccess(message) {
        this.showToast(message, 'success');
    }

    showInfo(message) {
        this.showToast(message, 'info');
    }

    showToast(message, type = 'info') {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${this.getToastIcon(type)}"></i>
            <span>${message}</span>
        `;

        // Add to container or create one
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }

        container.appendChild(toast);

        // Remove after delay
        setTimeout(() => {
            toast.remove();
        }, 4000);
    }

    getToastIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            info: 'info-circle',
            warning: 'exclamation-triangle'
        };
        return icons[type] || 'info-circle';
    }

    // Admin Functionality
    setupAdminAccess() {
        // Show admin access button on triple click (hidden feature)
        let clickCount = 0;
        let lastClick = 0;
        
        document.addEventListener('click', (e) => {
            const currentTime = new Date().getTime();
            
            if (currentTime - lastClick > 1000) {
                clickCount = 0;
            }
            
            clickCount++;
            lastClick = currentTime;
            
            if (clickCount === 3) {
                this.showAdminAccessButton();
                clickCount = 0;
            }
        });
    }

    showAdminAccessButton() {
        const adminAccess = document.querySelector('.admin-access');
        if (adminAccess) {
            adminAccess.style.display = 'block';
            this.showInfo('Admin access unlocked');
        }
    }

    showAdminModal() {
        const modal = document.getElementById('adminModal');
        if (modal) {
            modal.classList.add('active');
            this.loadCurrentBrandSettings();
        }
    }

    hideAdminModal() {
        const modal = document.getElementById('adminModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    loadCurrentBrandSettings() {
        // Load current settings from localStorage or defaults
        const brandName = localStorage.getItem('brandName') || 'ZAWADI';
        const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
        const logoChar = localStorage.getItem('logoChar') || 'Z';

        document.getElementById('companyName').value = brandName;
        document.getElementById('companyTagline').value = brandTagline;
        document.getElementById('logoCharacter').value = logoChar;
    }

    handleAdminSettings(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const companyName = formData.get('companyName');
        const companyTagline = formData.get('companyTagline');
        const logoCharacter = formData.get('logoCharacter');

        // Validate inputs
        if (!companyName.trim()) {
            this.showError('Company name is required');
            return;
        }

        if (!logoCharacter.trim()) {
            this.showError('Logo character is required');
            return;
        }

        // Save to localStorage
        localStorage.setItem('brandName', companyName);
        localStorage.setItem('brandTagline', companyTagline);
        localStorage.setItem('logoChar', logoCharacter);

        // Update the page in real-time
        this.updateBrandDisplay();

        this.showSuccess('Brand settings updated successfully!');
        this.hideAdminModal();
    }

    loadBrandSettings() {
        this.updateBrandDisplay();
    }

    updateBrandDisplay() {
        // Update all brand-related elements on the page
        const brandName = localStorage.getItem('brandName') || 'ZAWADI';
        const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
        const logoChar = localStorage.getItem('logoChar') || 'Z';

        // Update page title
        document.title = document.title.replace(/ZAWADI/g, brandName);

        // Update all brand name elements
        document.querySelectorAll('[data-brand-name]').forEach(element => {
            element.textContent = brandName;
        });

        // Update all brand tagline elements
        document.querySelectorAll('[data-brand-tagline]').forEach(element => {
            element.textContent = brandTagline;
        });

        // Update all logo characters
        document.querySelectorAll('[data-brand-logo-char]').forEach(element => {
            element.textContent = logoChar;
        });

        // Update admin form inputs if they exist
        const nameInput = document.querySelector('[data-brand-name-input]');
        const taglineInput = document.querySelector('[data-brand-tagline-input]');
        const logoInput = document.querySelector('[data-brand-logo-input]');

        if (nameInput) nameInput.value = brandName;
        if (taglineInput) taglineInput.value = brandTagline;
        if (logoInput) logoInput.value = logoChar;
    }
}

// Initialize login manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LoginManager();
});

// Utility function to update brand across all pages
function updateGlobalBrandSettings() {
    const brandName = localStorage.getItem('brandName') || 'ZAWADI';
    const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
    const logoChar = localStorage.getItem('logoChar') || 'Z';

    // This function would be called on every page load
    document.querySelectorAll('[data-brand-name]').forEach(el => {
        el.textContent = brandName;
    });
    document.querySelectorAll('[data-brand-tagline]').forEach(el => {
        el.textContent = brandTagline;
    });
    document.querySelectorAll('[data-brand-logo-char]').forEach(el => {
        el.textContent = logoChar;
    });
}

// Call this on every page to ensure brand consistency
updateGlobalBrandSettings();
// Brand Management System - Add this to main.js
document.addEventListener('DOMContentLoaded', function() {
    // Load brand settings on every page
    const brandName = localStorage.getItem('brandName') || 'ZAWADI';
    const brandTagline = localStorage.getItem('brandTagline') || 'Premium African-inspired sportswear';
    const logoChar = localStorage.getItem('logoChar') || 'Z';

    // Update all brand elements
    document.querySelectorAll('[data-brand-name]').forEach(element => {
        element.textContent = brandName;
    });
    
    document.querySelectorAll('[data-brand-tagline]').forEach(element => {
        element.textContent = brandTagline;
    });
    
    document.querySelectorAll('[data-brand-logo-char]').forEach(element => {
        element.textContent = logoChar;
    });

    // Update page title if it contains the brand name
    if (document.title.includes('ZAWADI')) {
        document.title = document.title.replace('ZAWADI', brandName);
    }
});