// Cart Management
class CartManager {
    constructor() {
        this.init();
    }

    init() {
        this.loadCartItems();
        this.setupEventListeners();
    }

    loadCartItems() {
        const cartItemsContainer = document.querySelector('.cart-items');
        if (!cartItemsContainer) return;

        const cart = window.zawadiApp.cart;

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="empty-cart" style="padding: 3rem; text-align: center;">
                    <h2>Your cart is empty</h2>
                    <p style="margin: 1rem 0 2rem; opacity: 0.7;">Browse our products and add items to your cart.</p>
                    <a href="shop.html" class="btn btn-primary">Start Shopping</a>
                </div>
            `;
            this.updateCartSummary();
            return;
        }

        cartItemsContainer.innerHTML = cart.map(item => `
            <div class="cart-item" data-item-id="${item.id}">
                <div class="cart-item-image">
                    <i class="fas fa-tshirt"></i>
                </div>
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p>Size: ${item.selectedSize}</p>
                    <div class="cart-item-price">£${(item.price * item.quantity).toFixed(2)}</div>
                    <div class="quantity-controls">
                        <button class="quantity-btn" onclick="cartManager.updateQuantity(${item.id}, ${item.quantity - 1}, '${item.selectedSize}')">-</button>
                        <span class="quantity">${item.quantity}</span>
                        <button class="quantity-btn" onclick="cartManager.updateQuantity(${item.id}, ${item.quantity + 1}, '${item.selectedSize}')">+</button>
                    </div>
                </div>
                <button class="remove-item" onclick="cartManager.removeItem(${item.id}, '${item.selectedSize}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');

        this.updateCartSummary();
    }

    setupEventListeners() {
        // Additional event listeners can be added here
    }

    updateQuantity(productId, newQuantity, size) {
        if (newQuantity < 1) {
            this.removeItem(productId, size);
            return;
        }

        window.zawadiApp.updateCartQuantity(productId, newQuantity, size);
        this.loadCartItems();
    }

    removeItem(productId, size) {
        window.zawadiApp.removeFromCart(productId, size);
        this.loadCartItems();
    }

    updateCartSummary() {
        const cart = window.zawadiApp.cart;
        const subtotalElement = document.getElementById('subtotal');
        const discountElement = document.getElementById('discount');
        const totalElement = document.getElementById('total');

        let subtotal = 0;
        cart.forEach(item => {
            subtotal += item.price * item.quantity;
        });

        const discount = 0; // Broker discount would be calculated here
        const total = subtotal - discount;

        if (subtotalElement) subtotalElement.textContent = `£${subtotal.toFixed(2)}`;
        if (discountElement) discountElement.textContent = `-£${discount.toFixed(2)}`;
        if (totalElement) totalElement.textContent = `£${total.toFixed(2)}`;
    }
}

// Initialize cart manager
const cartManager = new CartManager();