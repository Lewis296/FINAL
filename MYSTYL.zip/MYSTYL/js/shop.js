// Shop Page Functionality
class ShopPage {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentView = 'grid';
        this.currentPage = 1;
        this.productsPerPage = 12;
        this.filters = {
            category: [],
            price: 200,
            size: [],
            color: [],
            brand: []
        };
        this.sortBy = 'featured';
        this.currentCategory = this.getUrlParameter('category') || 'all';
        this.currentSubcategory = this.getUrlParameter('subcategory') || '';
        this.searchQuery = this.getUrlParameter('search') || '';
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadProducts();
        this.updatePageTitle();
        this.setupSubcategories();
        this.applyInitialFilters();
        this.updateBranding();
        this.setupBrandSync();
    }

    setupEventListeners() {
        // Filter toggle
        document.getElementById('filterToggle').addEventListener('click', () => {
            this.toggleFilterSidebar();
        });

        document.getElementById('closeFilters').addEventListener('click', () => {
            this.toggleFilterSidebar();
        });

        // View toggle
        document.querySelectorAll('.view-toggle').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchView(e.target.dataset.view);
            });
        });

        // Sort select
        document.getElementById('sortSelect').addEventListener('change', (e) => {
            this.sortBy = e.target.value;
            this.applyFilters();
        });

        // Filter changes
        document.querySelectorAll('input[name="category"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => this.updateCategoryFilters());
        });

        document.querySelectorAll('input[name="color"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => this.updateColorFilters());
        });

        document.querySelectorAll('input[name="brand"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => this.updateBrandFilters());
        });

        document.getElementById('priceRange').addEventListener('input', (e) => {
            this.filters.price = parseInt(e.target.value);
            document.querySelector('.range-values span:last-child').textContent = `£${e.target.value}+`;
        });

        // Filter actions
        document.getElementById('applyFilters').addEventListener('click', () => {
            this.applyFilters();
        });

        document.getElementById('clearFilters').addEventListener('click', () => {
            this.clearFilters();
        });

        document.getElementById('resetSearch').addEventListener('click', () => {
            this.clearFilters();
        });

        // Load more
        document.getElementById('loadMore').addEventListener('click', () => {
            this.loadMoreProducts();
        });

        // Search functionality
        const searchInput = document.querySelector('.search-input');
        const searchBtn = document.querySelector('.search-btn');
        
        if (searchInput && searchBtn) {
            searchBtn.addEventListener('click', () => this.handleSearch());
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.handleSearch();
            });
        }
    }

    loadProducts() {
        // Show loading state
        this.showLoadingState(true);

        // Simulate API call
        setTimeout(() => {
            this.products = this.generateSampleProducts();
            this.applyInitialFilters();
            this.showLoadingState(false);
        }, 1000);
    }

    generateSampleProducts() {
        const categories = {
            shoes: ['Sneakers', 'Boots', 'Sandals', 'Formal'],
            clothing: ['T-Shirts', 'Hoodies', 'Jackets', 'Pants'],
            accessories: ['Bags', 'Hats', 'Socks', 'Belts']
        };

        const brands = ['Nike', 'Adidas', 'Puma', 'New Balance', 'MYSTYL'];
        const sizes = ['S', 'M', 'L', 'XL', 'UK 6', 'UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'];
        const colors = ['black', 'white', 'blue', 'red', 'green', 'gray'];

        let products = [];

        // Generate shoes
        categories.shoes.forEach(type => {
            for (let i = 1; i <= 8; i++) {
                products.push({
                    id: `shoe-${type.toLowerCase()}-${i}`,
                    name: `${type} ${i}`,
                    category: 'shoes',
                    subcategory: type.toLowerCase(),
                    price: Math.floor(Math.random() * 100) + 50,
                    originalPrice: Math.floor(Math.random() * 50) + 100,
                    brand: brands[Math.floor(Math.random() * brands.length)],
                    sizes: sizes.slice(4, 9),
                    colors: [colors[Math.floor(Math.random() * colors.length)]],
                    rating: (Math.random() * 2 + 3).toFixed(1),
                    reviewCount: Math.floor(Math.random() * 100) + 10,
                    image: 'fas fa-shoe-prints',
                    description: `Premium ${type.toLowerCase()} with comfortable fit and modern design.`,
                    isNew: Math.random() > 0.7,
                    onSale: Math.random() > 0.5
                });
            }
        });

        // Generate clothing
        categories.clothing.forEach(type => {
            for (let i = 1; i <= 8; i++) {
                products.push({
                    id: `clothing-${type.toLowerCase()}-${i}`,
                    name: `${type} ${i}`,
                    category: 'clothing',
                    subcategory: type.toLowerCase(),
                    price: Math.floor(Math.random() * 60) + 20,
                    originalPrice: Math.floor(Math.random() * 30) + 60,
                    brand: brands[Math.floor(Math.random() * brands.length)],
                    sizes: sizes.slice(0, 5),
                    colors: [colors[Math.floor(Math.random() * colors.length)]],
                    rating: (Math.random() * 2 + 3).toFixed(1),
                    reviewCount: Math.floor(Math.random() * 100) + 10,
                    image: type === 'T-Shirts' ? 'fas fa-tshirt' : 
                           type === 'Hoodies' ? 'fas fa-hoodie' : 
                           type === 'Jackets' ? 'fas fa-jacket' : 'fas fa-vest',
                    description: `Comfortable ${type.toLowerCase()} made from premium materials.`,
                    isNew: Math.random() > 0.7,
                    onSale: Math.random() > 0.5
                });
            }
        });

        // Generate accessories
        categories.accessories.forEach(type => {
            for (let i = 1; i <= 6; i++) {
                products.push({
                    id: `accessory-${type.toLowerCase()}-${i}`,
                    name: `${type} ${i}`,
                    category: 'accessories',
                    subcategory: type.toLowerCase(),
                    price: Math.floor(Math.random() * 40) + 10,
                    originalPrice: Math.floor(Math.random() * 20) + 40,
                    brand: brands[Math.floor(Math.random() * brands.length)],
                    sizes: ['One Size'],
                    colors: [colors[Math.floor(Math.random() * colors.length)]],
                    rating: (Math.random() * 2 + 3).toFixed(1),
                    reviewCount: Math.floor(Math.random() * 100) + 10,
                    image: type === 'Bags' ? 'fas fa-bag-shopping' : 
                           type === 'Hats' ? 'fas fa-hat-cowboy' : 
                           type === 'Socks' ? 'fas fa-socks' : 'fas fa-belt',
                    description: `Stylish ${type.toLowerCase()} to complement your outfit.`,
                    isNew: Math.random() > 0.7,
                    onSale: Math.random() > 0.5
                });
            }
        });

        return products;
    }

    applyInitialFilters() {
        // Set initial category filter based on URL
        if (this.currentCategory !== 'all') {
            this.filters.category = [this.currentCategory];
            document.querySelectorAll(`input[name="category"][value="${this.currentCategory}"]`).forEach(checkbox => {
                checkbox.checked = true;
            });
        }

        // Apply subcategory filter if present
        if (this.currentSubcategory) {
            this.applySubcategoryFilter(this.currentSubcategory);
        }

        // Apply search filter if present
        if (this.searchQuery) {
            this.applySearchFilter(this.searchQuery);
        }

        this.applyFilters();
    }

    applySubcategoryFilter(subcategory) {
        this.filteredProducts = this.products.filter(product => 
            product.subcategory === subcategory
        );
        this.displayProducts();
    }

    applySearchFilter(query) {
        this.searchQuery = query.toLowerCase();
        this.applyFilters();
    }

    updateCategoryFilters() {
        this.filters.category = Array.from(document.querySelectorAll('input[name="category"]:checked'))
            .map(checkbox => checkbox.value);
    }

    updateColorFilters() {
        this.filters.color = Array.from(document.querySelectorAll('input[name="color"]:checked'))
            .map(checkbox => checkbox.value);
    }

    updateBrandFilters() {
        this.filters.brand = Array.from(document.querySelectorAll('input[name="brand"]:checked'))
            .map(checkbox => checkbox.value);
    }

    applyFilters() {
        let filtered = [...this.products];

        // Apply category filter
        if (this.filters.category.length > 0) {
            filtered = filtered.filter(product => 
                this.filters.category.includes(product.category)
            );
        }

        // Apply price filter
        filtered = filtered.filter(product => product.price <= this.filters.price);

        // Apply color filter
        if (this.filters.color.length > 0) {
            filtered = filtered.filter(product => 
                product.colors.some(color => this.filters.color.includes(color))
            );
        }

        // Apply brand filter
        if (this.filters.brand.length > 0) {
            filtered = filtered.filter(product => 
                this.filters.brand.includes(product.brand.toLowerCase())
            );
        }

        // Apply search filter
        if (this.searchQuery) {
            filtered = filtered.filter(product => 
                product.name.toLowerCase().includes(this.searchQuery) ||
                product.brand.toLowerCase().includes(this.searchQuery) ||
                product.description.toLowerCase().includes(this.searchQuery)
            );
        }

        // Apply sorting
        filtered = this.sortProducts(filtered);

        this.filteredProducts = filtered;
        this.currentPage = 1;
        this.displayProducts();
    }

    sortProducts(products) {
        switch (this.sortBy) {
            case 'newest':
                return products.sort((a, b) => b.id.localeCompare(a.id));
            case 'price-low':
                return products.sort((a, b) => a.price - b.price);
            case 'price-high':
                return products.sort((a, b) => b.price - a.price);
            case 'name':
                return products.sort((a, b) => a.name.localeCompare(b.name));
            case 'featured':
            default:
                return products.sort((a, b) => b.rating - a.rating);
        }
    }

    displayProducts() {
        const container = document.getElementById('productsGrid');
        const noResults = document.getElementById('noResults');
        const loadMoreBtn = document.getElementById('loadMore');

        if (this.filteredProducts.length === 0) {
            container.innerHTML = '';
            noResults.classList.add('active');
            loadMoreBtn.style.display = 'none';
            return;
        }

        noResults.classList.remove('active');

        const startIndex = 0;
        const endIndex = this.currentPage * this.productsPerPage;
        const productsToShow = this.filteredProducts.slice(startIndex, endIndex);

        container.className = this.currentView === 'grid' ? 'products-grid' : 'products-list';
        
        container.innerHTML = productsToShow.map(product => this.createProductCard(product)).join('');

        // Show/hide load more button
        loadMoreBtn.style.display = endIndex < this.filteredProducts.length ? 'block' : 'none';

        // Add event listeners to product cards
        this.attachProductCardEvents();
    }

    createProductCard(product) {
        const isListView = this.currentView === 'list';
        const badge = product.onSale ? 'sale' : product.isNew ? 'new' : '';

        return `
            <div class="product-card" data-product-id="${product.id}">
                ${badge ? `<div class="product-badge ${badge}">${badge === 'sale' ? 'Sale' : 'New'}</div>` : ''}
                
                <div class="product-image">
                    <i class="${product.image}"></i>
                    <div class="product-actions">
                        <button class="btn-icon quick-view" title="Quick View">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-icon add-to-wishlist" title="Add to Wishlist">
                            <i class="far fa-heart"></i>
                        </button>
                    </div>
                </div>
                
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <div class="product-meta">
                        <div class="price">
                            ${product.onSale ? `
                                <span class="original-price">£${product.originalPrice}</span>
                                <span class="sale-price">£${product.price}</span>
                            ` : `
                                <span>£${product.price}</span>
                            `}
                        </div>
                        <div class="rating">
                            <i class="fas fa-star"></i>
                            <span>${product.rating}</span>
                            <span>(${product.reviewCount})</span>
                        </div>
                    </div>
                    
                    ${isListView ? `
                        <p class="product-description">${product.description}</p>
                        <div class="product-details">
                            <span class="brand">${product.brand}</span>
                            <span class="colors">Available in ${product.colors.length} colors</span>
                        </div>
                    ` : ''}
                    
                    <button class="btn btn-outline btn-sm add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        `;
    }

    attachProductCardEvents() {
        // Product card click
        document.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.btn-icon') && !e.target.closest('.add-to-cart-btn')) {
                    const productId = card.dataset.productId;
                    window.location.href = `product-details.html?id=${productId}`;
                }
            });
        });

        // Add to cart
        document.querySelectorAll('.add-to-cart-btn').forEach((btn, index) => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const product = this.filteredProducts[index];
                if (window.zawadiApp) {
                    window.zawadiApp.addToCart(product);
                } else {
                    this.showToast(`${product.name} added to cart!`, 'success');
                }
            });
        });

        // Quick view
        document.querySelectorAll('.quick-view').forEach((btn, index) => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const product = this.filteredProducts[index];
                this.showQuickView(product);
            });
        });

        // Wishlist
        document.querySelectorAll('.add-to-wishlist').forEach((btn, index) => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const product = this.filteredProducts[index];
                this.addToWishlist(product);
            });
        });
    }

    switchView(view) {
        this.currentView = view;
        
        // Update active state
        document.querySelectorAll('.view-toggle').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === view);
        });

        this.displayProducts();
    }

    toggleFilterSidebar() {
        const sidebar = document.getElementById('filterSidebar');
        sidebar.classList.toggle('active');
    }

    clearFilters() {
        // Reset all checkboxes
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.checked = false;
        });

        // Reset price range
        document.getElementById('priceRange').value = 200;
        document.querySelector('.range-values span:last-child').textContent = '£200+';

        // Reset filters object
        this.filters = {
            category: [],
            price: 200,
            size: [],
            color: [],
            brand: []
        };

        this.searchQuery = '';
        this.applyFilters();
    }

    loadMoreProducts() {
        this.currentPage++;
        this.displayProducts();
    }

    showLoadingState(show) {
        const loadingState = document.getElementById('loadingState');
        if (show) {
            loadingState.classList.add('active');
        } else {
            loadingState.classList.remove('active');
        }
    }

    updatePageTitle() {
        const title = document.getElementById('pageTitle');
        const currentCategory = document.getElementById('currentCategory');
        
        let categoryText = 'All Products';
        let description = 'Discover our premium collection';

        switch (this.currentCategory) {
            case 'shoes':
                categoryText = 'Shoes';
                description = 'Step up your style with our premium footwear';
                break;
            case 'clothing':
                categoryText = 'Clothing';
                description = 'Dress to impress with our fashion collection';
                break;
            case 'accessories':
                categoryText = 'Accessories';
                description = 'Complete your look with our accessories';
                break;
        }

        if (this.searchQuery) {
            categoryText = `Search: "${this.searchQuery}"`;
            description = `Results for "${this.searchQuery}"`;
        }

        title.textContent = categoryText;
        currentCategory.textContent = categoryText;
        document.getElementById('pageDescription').textContent = description;
    }

    setupSubcategories() {
        const subcategoriesContainer = document.getElementById('subcategories');
        const subcategories = this.getSubcategoriesForCurrentCategory();

        if (subcategories.length > 0) {
            subcategoriesContainer.innerHTML = subcategories.map(sub => `
                <button class="subcategory-btn ${this.currentSubcategory === sub.value ? 'active' : ''}" 
                        data-subcategory="${sub.value}">
                    ${sub.label}
                </button>
            `).join('');

            // Add event listeners to subcategory buttons
            subcategoriesContainer.querySelectorAll('.subcategory-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const subcategory = e.target.dataset.subcategory;
                    this.applySubcategoryFilter(subcategory);
                    
                    // Update active state
                    subcategoriesContainer.querySelectorAll('.subcategory-btn').forEach(b => {
                        b.classList.remove('active');
                    });
                    e.target.classList.add('active');
                });
            });
        } else {
            subcategoriesContainer.style.display = 'none';
        }
    }

    getSubcategoriesForCurrentCategory() {
        const subcategories = {
            shoes: [
                { value: 'sneakers', label: 'Sneakers' },
                { value: 'boots', label: 'Boots' },
                { value: 'sandals', label: 'Sandals' },
                { value: 'formal', label: 'Formal' }
            ],
            clothing: [
                { value: 't-shirts', label: 'T-Shirts' },
                { value: 'hoodies', label: 'Hoodies' },
                { value: 'jackets', label: 'Jackets' },
                { value: 'pants', label: 'Pants' }
            ],
            accessories: [
                { value: 'bags', label: 'Bags' },
                { value: 'hats', label: 'Hats' },
                { value: 'socks', label: 'Socks' },
                { value: 'belts', label: 'Belts' }
            ]
        };

        return subcategories[this.currentCategory] || [];
    }

    showQuickView(product) {
        // In a real implementation, this would show a modal with product details
        this.showToast(`Quick view: ${product.name}`, 'info');
    }

    addToWishlist(product) {
        if (window.zawadiApp) {
            window.zawadiApp.showToast(`${product.name} added to wishlist!`, 'success');
        } else {
            this.showToast(`${product.name} added to wishlist!`, 'success');
        }
    }

    handleSearch() {
        const searchInput = document.querySelector('.search-input');
        const query = searchInput.value.trim();
        
        if (query) {
            this.searchQuery = query.toLowerCase();
            this.applyFilters();
            this.updatePageTitle();
        }
    }

    getUrlParameter(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    setupBrandSync() {
        window.addEventListener('storage', (e) => {
            if (e.key === 'zawadiBrandConfig') {
                this.updateBranding();
            }
        });
    }

    updateBranding() {
        const brandConfig = JSON.parse(localStorage.getItem('zawadiBrandConfig')) || {
            name: 'MYSTYL',
            tagline: 'Premium African-inspired Sportswear',
            logoChar: 'M'
        };

        document.querySelectorAll('[data-brand-name]').forEach(el => {
            if (el.tagName === 'TITLE') {
                el.textContent = el.textContent.replace(/MYSTYL/g, brandConfig.name);
            } else {
                el.textContent = brandConfig.name;
            }
        });

        document.querySelectorAll('[data-brand-tagline]').forEach(el => {
            el.textContent = brandConfig.tagline;
        });

        document.querySelectorAll('[data-brand-logo-char]').forEach(el => {
            el.textContent = brandConfig.logoChar;
        });
    }

    showToast(message, type = 'info') {
        if (window.zawadiApp) {
            window.zawadiApp.showToast(message, type);
        } else {
            // Fallback toast
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                background: var(--card-bg);
                color: var(--text-color);
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: var(--shadow);
                z-index: 1000;
                border-left: 4px solid ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#6366f1'};
            `;
            toast.textContent = message;
            document.body.appendChild(toast);
            
            setTimeout(() => toast.remove(), 3000);
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ShopPage();
});